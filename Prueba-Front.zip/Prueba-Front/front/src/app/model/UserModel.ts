/**
 * clase utilizada para mapear la informacion del CRUD de Usuario.
 */
export class UserModel {
  public email: string;
  public lastName: string;
  public name: string;
  public password: string;
  public id: number;
}
