import { Injectable } from "@angular/core";
import { HttpHeaders, HttpClient, HttpParams } from "@angular/common/http";
import { UserModel } from "./model/UserModel";
import { Observable } from "rxjs";

@Injectable({
  providedIn: "root"
})
export class CrudService {
  private headers: HttpHeaders;

  constructor(private http: HttpClient) {
    this.headers = new HttpHeaders();
    this.headers = this.headers.append("Content-Type", "application/json");
  }

  /**
   * Metodo encargado de actualizar un usuario
   * @param params usuario a actualizar
   */
  public updateUser(params: UserModel): Observable<UserModel> {
    return this.http.put<UserModel>(
      "http://localhost:8080/usercontroller/user/",
      params,
      {
        headers: this.headers
      }
    );
  }

  /**
   * Metodo encargado de crear un nuevo usuario
   * @param params usuario a crear
   */
  public createUser(params: UserModel): Observable<UserModel> {
    return this.http.post<UserModel>(
      "http://localhost:8080/usercontroller/user/",
      params,
      {
        headers: this.headers
      }
    );
  }

  /**
   * Metodo para obtencion de todos los usuarios
   */
  public getUsers(): Observable<UserModel[]> {
    return this.http.get<UserModel[]>(
      "http://localhost:8080/usercontroller/users"
    );
  }

  /**
   * Metodo para eliminar un usuario especifico
   * @param id ID de usuario a eliminar
   */
  public deleteUser(id: number): Observable<boolean> {
    return this.http.delete<boolean>(
      "http://localhost:8080/usercontroller/user/" + id
    );
  }
}
