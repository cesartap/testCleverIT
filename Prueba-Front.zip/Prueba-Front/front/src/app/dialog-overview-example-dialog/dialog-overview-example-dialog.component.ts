import { Component, Inject, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { CrudService } from "../crud.service";
import { UserModel } from "../model/UserModel";

@Component({
  selector: "app-dialog-overview-example-dialog",
  templateUrl: "./dialog-overview-example-dialog.component.html",
  styleUrls: ["./dialog-overview-example-dialog.component.css"]
})
export class DialogOverviewExampleDialogComponent implements OnInit {
  constructor(
    public dialogRef: MatDialogRef<DialogOverviewExampleDialogComponent>,
    private crudService: CrudService,
    @Inject(MAT_DIALOG_DATA) public data: UserModel
  ) {}

  ngOnInit() {}

  /**
   * Funcion para cerrar la ventana modal
   */
  onNoClick(): void {
    this.dialogRef.close();
  }

  /**
   * Metodo encargado de discriminar si es una creacion o actualizacion
   * de usuario
   * @param datos Data UserModel
   */
  check(datos: UserModel) {
    if (null == datos.id) {
      this.createUser(datos);
    } else {
      this.update(datos);
    }
  }

  /**
   * Metodo encargado de actualizar un usuario especifico
   * @param datos Datos userModel
   */
  update(datos: UserModel) {
    this.crudService.updateUser(datos).subscribe(
      (response: any) => {
        this.onNoClick();
      },
      error => {
        console.error("[updateUser] Error al actualizar los datos.");
      }
    );
  }

  /**
   * Metodo encargado de crear un nuevo usuario.
   * @param datos Datos de Usermodel
   */
  createUser(datos: UserModel) {
    this.crudService.createUser(datos).subscribe(
      (response: any) => {
        this.onNoClick();
      },
      error => {
        console.error("[createUser] Error al crear usuario.");
      }
    );
  }
}
