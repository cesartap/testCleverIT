import { Component } from "@angular/core";
import { MatTableDataSource } from "@angular/material/table";
import { UserModel } from "./model/UserModel";
import { CrudService } from "./crud.service";
import { MatDialog } from '@angular/material/dialog';
import { DialogOverviewExampleDialogComponent } from './dialog-overview-example-dialog/dialog-overview-example-dialog.component';

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  // columnas
  displayedColumns: string[] = ["email", "lastName", "name", "password", "id","action"];
  columnsToDisplay: string[] = this.displayedColumns.slice();
  
  // datatable
  data: MatTableDataSource<UserModel> = new MatTableDataSource();

  constructor(private crudService: CrudService, public dialog: MatDialog) {}

  /**
   * Utilizado para rellenar los valores al comienzo
   */
  ngOnInit() {
    this.getUsers();
  }

  /**
   * Metodo encargado de crear un nuevo usaurio. No se le envia ningun
   * valor a la ventana modal para indicar que es un usuario nuevo.
   */
  addItem() {
    this.openDialog(null,null,null,null,null);
  }


/**
 * Metodo encargado de eliminar un dato especifico.
 * Si todo sale OK, se procede a buscar nuevamente los usuarios.
 * @param id ID de usuario
 */
  deleteItem(id:number){
    this.crudService.deleteUser(id).subscribe(
      (response: any) => {
        this.getUsers();
      },
      error => {
        console.error("[deleteItem] Error al eliminar los datos.");
      }
    );
  }

/**
 * Metodo encargado de ir a buscar los usuarios disponibles,
 * se encarga de limpiar la data cada vez que la refresca
 */
  public getUsers() {
    this.data = new MatTableDataSource();
    this.crudService.getUsers().subscribe(
      (response: any) => {
        const listaUsuarios: UserModel[] = [];
        response.userList.forEach(element => {
          const u : UserModel= element;
          listaUsuarios.push(u);
        });

        this.data = new MatTableDataSource(listaUsuarios);
      },
      error => {
        console.error("[getUsers] Error al obtener los datos.");
      }
    );
  }

/**
 * Metodo para crear una ventana modal que sera usada para crear/actualizar registros
 * @param rowid ID de usuario
 * @param rowemail Email de usuario
 * @param rowlastName Apellido de usuario
 * @param rowname Nombre de usuario
 * @param rowpassword Contrasena de usuario
 */
  openDialog(rowid: number, rowemail: string, rowlastName:string, rowname:string, rowpassword:string): void {
    const dialogRef = this.dialog.open(DialogOverviewExampleDialogComponent, {
      width: '250px',
      data: {email: rowemail, lastName: rowlastName, name: rowname, password:rowpassword,id: rowid}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('Dialogo cerrado');
      this.getUsers();
    });
  }
}

